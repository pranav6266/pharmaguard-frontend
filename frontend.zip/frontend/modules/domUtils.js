// DOM Utilities

export function setStatus(msg, isError) {
  const validateStatus = document.getElementById("validate-status");
  if (!validateStatus) return;
  validateStatus.textContent = msg || "";
  validateStatus.style.color = isError ? "#dc2626" : "#16a34a";
  validateStatus.style.fontWeight = "500";
}

export function initializeDrugCheckboxes() {
  const drugCheckboxes = document.querySelectorAll(
    'input[type="checkbox"][id^="drug-"]',
  );
  const selectedDrugs = new Set();

  drugCheckboxes.forEach((checkbox) => {
    if (checkbox.checked) {
      selectedDrugs.add(checkbox.value);
    }

    checkbox.addEventListener("change", (e) => {
      if (e.target.checked) {
        selectedDrugs.add(e.target.value);
      } else {
        selectedDrugs.delete(e.target.value);
      }
    });
  });
}
