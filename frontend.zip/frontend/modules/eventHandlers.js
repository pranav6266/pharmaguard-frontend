// Event Handlers

import { setStatus } from "./domUtils.js";
import { apiBase } from "./config.js";

export function handleFileInput(event) {
  const fileInput = event.target;
  const selectedFileP = document.getElementById("selected-file");

  if (fileInput.files.length > 0) {
    const file = fileInput.files[0];
    selectedFileP.textContent = `Selected file: ${file.name}`;
  } else {
    selectedFileP.textContent = "No file selected.";
  }
}

export function handleRunAnalysis() {
  const selectedFile = document.getElementById("vcf-file-input").files[0];
  const selectedDrugs = Array.from(
    document.querySelectorAll('input[type="checkbox"]:checked'),
  ).map((checkbox) => checkbox.value);

  if (!selectedFile) {
    setStatus("Please select a file to analyze.", true);
    return;
  }

  const formData = new FormData();
  formData.append("file", selectedFile);
  formData.append("drugs", selectedDrugs.join(","));

  fetch(`${apiBase}/full-analysis`, {
    method: "POST",
    body: formData,
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to analyze file.");
      }
      return response.json();
    })
    .then((data) => {
      console.log("Analysis results:", data);
      setStatus("Analysis completed successfully.", false);
    })
    .catch((error) => {
      console.error(error);
      setStatus("An error occurred during analysis.", true);
    });
}
