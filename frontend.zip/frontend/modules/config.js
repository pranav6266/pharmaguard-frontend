// Configuration

export const apiBase =
  location.hostname === "localhost" || location.hostname === "127.0.0.1"
    ? `${location.protocol}//${location.hostname}:8000`
    : `${location.protocol}//${location.hostname}:8000`;
