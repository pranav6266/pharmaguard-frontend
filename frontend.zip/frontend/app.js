// PharmaGuard - Application Logic

// Import modules
import { initializeDrugCheckboxes, setStatus } from "./modules/domUtils.js";
import { apiBase } from "./modules/config.js";
import { handleFileInput, handleRunAnalysis } from "./modules/eventHandlers.js";

(function () {
  // Initialize drug checkboxes
  initializeDrugCheckboxes();

  // Event listeners
  const fileInput = document.getElementById("vcf-file-input");
  const runBtn = document.getElementById("run-analysis-btn");

  fileInput.addEventListener("change", handleFileInput);
  runBtn.addEventListener("click", handleRunAnalysis);
})();
